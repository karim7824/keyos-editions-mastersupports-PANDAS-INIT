> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 6 : Opérations sur les données | Exercice 1*

---

# Chapitre 6 : Opérations sur les données

**Exercice 1 :** Diagnostic et Audit d'un Dataset de Ventes

On récupère un fichier CSV contenant des données de ventes brutes d'une entreprise e-commerce (`ventes_techno.csv`). Avant toute analyse marketing, on doit mener un audit rigoureux de la structure et de la santé des données.

```python
import pandas as pd
import io

csv_data = """id_vente,produit,categorie,prix_unitaire,quantite,date_vente
101,Clavier RGB,Accessoire,45.5,4,2026-05-10
102,Écran 27,Moniteur,299.0,2,2026-05-11
103,Souris Sans Fil,Accessoire,25.0,NaN,2026-05-11
104,PC Portable Pro,Ordinateur,1200.0,1,2026-05-12
105,Casque Audio,Accessoire,60.0,3,2026-05-13
"""
df_ventes = pd.read_csv(io.StringIO(csv_data))

```

* Importation et typage : Charge ce jeu de données en veillant à convertir la colonne `date_vente` directement en objets temporels (`datetime`) et à spécifier les colonnes catégorielles (`produit`, `categorie`).
* Inspection structurelle : Affiche les dimensions du DataFrame, la liste des axes (`.axes` ou `.columns`/`.index`), ainsi que le diagnostic complet de l'empreinte mémoire avec `info(memory_usage='deep')`.
* Audit des anomalies : Identifie le nombre de valeurs manquantes par colonne.
* Statistiques descriptives : Affiche un résumé statistique global (incluant les variables textuelles/catégorielles) pour évaluer les fourchettes de prix et les volumes.
