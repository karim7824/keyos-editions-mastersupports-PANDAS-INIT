> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 10 : Statistiques et agrégations | Exercice 1*

---

# Chapitre 10 : Statistiques et agrégations

**Exercice 1 :** Rapport de synthèse décisionnel par catégorie (`groupby` et `agg`)

En tant qu'analyste de données, la direction te demande de produire un tableau de bord synthétique pour analyser les performances des ventes par grande catégorie de produits.

```python
import pandas as pd

df_catalogue = pd.DataFrame({
    'Produit': ['Clavier', 'Souris', 'Casque', 'Webcam', 'Tapis', 'Écran'],
    'Categorie': ['Accessoire', 'Accessoire', 'Audio', 'Audio', 'Accessoire', 'Moniteur'],
    'Prix_HT': [50.0, 25.0, 80.0, 70.0, 15.0, 250.0],
    'Quantite_Vendue': [12, 45, 8, 15, 30, 5],
    'Chiffre_Affaires': [600.0, 1125.0, 640.0, 1050.0, 450.0, 1250.0]
})

```

À l'aide d'un enchaînement `groupby()` et `agg()`, construis un DataFrame de synthèse qui regroupe les données par `Categorie` et calcule pour chacune d'elles :

* Le nombre total de références distinctes (`count` sur la colonne `Produit`).
* Le prix unitaire moyen HT (`mean` sur la colonne `Prix_HT`), renommé explicitement `Prix_Moyen`.
* Le volume total d'articles vendus (`sum` sur la colonne `Quantite_Vendue`), renommé `Volume_Total`.
* Le chiffre d'affaires cumulé (`sum` sur la colonne `Chiffre_Affaires`), renommé `CA_Total`.
* Transforme l'index de groupe en colonne classique pour obtenir un tableau propre et plat.
