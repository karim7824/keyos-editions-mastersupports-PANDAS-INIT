> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 13 : Gestion des structures multidimensionnelles | Exercice 1*

---

# Chapitre 13 : Gestion des structures multidimensionnelles

**Exercice 1 :** Manipulation d'un MultiIndex et sélection

Créez un DataFrame comportant un `MultiIndex` à deux niveaux : `"Ville"` (`"Paris"`, `"Marseille"`) et `"Mois"` (`"Janvier"`, `"Février"`), contenant une colonne `"Consommation_Elec_kWh"`.
Utilisez l'attribut `.loc` pour extraire l'ensemble des données relatives à la ville de `"Paris"`.
