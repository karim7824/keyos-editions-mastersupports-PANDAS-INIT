> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 13 : Gestion des structures multidimensionnelles | Exercice 2*

---

# Chapitre 13 : Gestion des structures multidimensionnelles

**Exercice 2 :** Utilisation de `pivot_table` et de `melt`

À partir du jeu de données suivant :

```python
import pandas as pd
df_donnees = pd.DataFrame({
    'Equipe': ['Dev', 'Dev', 'Ops', 'Ops'],
    'Projet': ['Alpha', 'Beta', 'Alpha', 'Beta'],
    'Budget': [50000, 30000, 20000, 45000]
})

```

Transformez ce tableau à l'aide de `pivot_table` pour obtenir les équipes en lignes, les projets en colonnes, et les budgets en valeurs.
Appliquez ensuite un `melt()` sur le résultat obtenu pour le ramener sous un format long.
