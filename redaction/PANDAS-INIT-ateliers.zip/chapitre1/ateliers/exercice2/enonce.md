> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 1 : Rappel NumPy | Exercice 2*

---

# Chapitre 1 : Rappel NumPy

**Exercice 2 :** Statistiques par axe et gestion des données manquantes

On dispose du tableau de températures suivant relevé dans 3 villes (lignes) sur 4 jours (colonnes) :

```python
temperatures = np.array([
    [21.5, 22.0, np.nan, 24.1],
    [15.0, 16.2, 17.0, 16.5],
    [28.0, np.nan, 30.2, 29.5]
])

```

Calculez la température moyenne pour chaque jour (en effectuant l'opération sur les lignes, `axis=0`) en gérant proprement les valeurs manquantes (`np.nan`).
Identifiez la ville (l'indice de la ligne) qui enregistre la température maximale globale sur l'ensemble de la période.
