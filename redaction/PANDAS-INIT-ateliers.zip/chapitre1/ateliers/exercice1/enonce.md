> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 1 : Rappel NumPy | Exercice 1*

---

# Chapitre 1 : Rappel NumPy

**Exercice 1 :** Manipulation de matrices et slicing

Créez un tableau NumPy unidimensionnel contenant les entiers de 10 à 50 (inclus).
Extrayez-en une tranche (slicing) contenant uniquement les nombres pairs situés entre les indices 10 et
