> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 15 : Visualisation de données avec Pandas (`df.plot()`) | Exercice 2*

---

# Chapitre 15 : Visualisation de données avec Pandas (`df.plot()`)

**Exercice 2 :** Génération d'une grille de graphiques multi-subplots

La direction souhaite analyser simultanément plusieurs indicateurs de performance d'un site web (visites, conversions et taux de rebond) sur une semaine. Plutôt que de multiplier les figures séparées, on doit concevoir un tableau de bord condensé.

Créez un `DataFrame` nommé `df_dashboard` à l'aide de la structure suivante :
```python
import pandas as pd

df_dashboard = pd.DataFrame({
    'Date': pd.date_range(start='2026-10-01', periods=5, freq='D'),
    'Visiteurs': [1200, 1450, 1300, 1600, 1850],
    'Conversions': [45, 60, 52, 70, 85],
    'Taux_Rebond': [0.45, 0.42, 0.48, 0.39, 0.35]
}).set_index('Date')

```

Utilisez la méthode `.plot()` en combinant les arguments **`subplots=True`** et **`layout=(2, 2)`** pour répartir les métriques dans une grille de sous-graphiques.
Ajustez les dimensions globales à `(10, 6)`, activez le partage de l'axe horizontal (`share=True`), et ajoutez des marqueurs sur les points (`marker='o'`).
Ajoutez un titre global à la figure (`plt.suptitle(...)`) et utilisez `plt.tight_layout()` pour éviter tout chevauchement avant d'afficher le résultat.
