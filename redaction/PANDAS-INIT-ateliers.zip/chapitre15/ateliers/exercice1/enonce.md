> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 15 : Visualisation de données avec Pandas (`df.plot()`) | Exercice 1*

---

# Chapitre 15 : Visualisation de données avec Pandas (`df.plot()`)

**Exercice 1 :** Création d'un graphique linéaire multi-courbes et habillage personnalisé

On suit l'évolution mensuelle des ventes de deux produits phares d'une entreprise au cours du premier semestre 2026. On doit représenter ces tendances sur un même graphique en veillant à soigner l'habillage visuel.

À l'aide de Pandas, créez un `DataFrame` nommé `df_suivi` contenant les données suivantes, avec les mois comme index :
* **`Mois`** : `['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin']`
* **`Produit_A`** : `[1200, 1350, 1500, 1420, 1600, 1750]`
* **`Produit_B`** : `[900, 1100, 1050, 1300, 1450, 1600]`
Définissez la colonne `'Mois'` comme index du DataFrame.
Utilisez la méthode `.plot()` pour tracer ces deux séries sous forme de graphique linéaire (`kind='line'`).
Personnalisez le graphique en ajoutant :
* Une dimension physique de `(8, 4)` via `figsize`.
* Un titre explicite (ex : *"Comparatif des ventes - 1er semestre 2026"*).
* Des libellés clairs sur les axes (`xlabel` et `ylabel`).
* Une grille en pointillés (`plt.grid()`).
