> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 7 : Filtrage et Mappage dans les DataFrames Pandas | Exercice 2*

---

# Chapitre 7 : Filtrage et Mappage dans les DataFrames Pandas

**Exercice 2 :** Enrichissement relationnel, Mapping et Filtrage
Croiser deux tables hétérogènes avec `pd.merge()`, traduire des codes via `.map()` et appliquer un filtre conditionnel multicritère.

On gére deux sources de données distinctes dans notre boutique : un historique de ventes contenant des identifiants produits, et un catalogue général fournissant les détails et les catégories.

Partez des deux DataFrames suivants :
```python
