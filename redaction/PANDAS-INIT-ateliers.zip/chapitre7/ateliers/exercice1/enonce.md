> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 7 : Filtrage et Mappage dans les DataFrames Pandas | Exercice 1*

---

# Chapitre 7 : Filtrage et Mappage dans les DataFrames Pandas

**Exercice 1 :** Analyse temporelle et extraction des pics d'activité
Manipuler les séries temporelles, convertir des chaînes de caractères en objets `datetime`, extraire des composantes temporelles et réaliser une agrégation croisée.

On dispose d'un journal de transactions brutes sous forme de texte. La direction souhaite identifier quels jours de la semaine génèrent le plus de chiffre d'affaires.

Créez un DataFrame contenant ces données brutes :
```python
import pandas as pd

df_logs = pd.DataFrame({
    'Horodatage': ['2026-10-01 09:30:00', '2026-10-02 14:15:00', '2026-10-03 18:45:00', 
                   '2026-10-04 10:00:00', '2026-10-05 16:20:00', '2026-10-06 11:10:00'],
    'Montant_EUR': [120.5, 45.0, 300.0, 85.0, 210.0, 95.0]
})

```
Convertissez la colonne `Horodatage` en un type `datetime` exploitable.
Extrayez le **nom du jour de la semaine** (ex : *Monday*, *Tuesday*...) dans une nouvelle colonne nommée `Jour_Semaine`.
Réalisez un regroupement (`groupby`) par `Jour_Semaine` pour calculer la somme totale du chiffre d'affaires (`Montant_EUR`) et le nombre de transactions par jour.
