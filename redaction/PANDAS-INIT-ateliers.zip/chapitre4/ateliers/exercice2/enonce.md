> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 4 : Présentation un DataFrame | Exercice 2*

---

# Chapitre 4 : Présentation un DataFrame

**Exercice 2 :** Utilisation des axes (`axis`) et calculs statistiques orientés

Un centre de formation souhaite analyser les notes semestrielles obtenues par ses étudiants dans différentes matières scientifiques. Vous devez charger ces données et exploiter le paramètre `axis` pour automatiser les calculs.

Créez un `DataFrame` nommé `df_notes` à partir du dictionnaire suivant, en définissant les noms des étudiants comme index (`index=['Élève_A', 'Élève_B', 'Élève_C']`) :
```python
data_notes = {
    'Algorithmique': [14, 16, 10],
    'Base_de_Donnees': [12, 18, 15],
    'Reseaux': [16, 14, 13]
}

```

Calculez et affichez la **moyenne par matière** en utilisant explicitement le paramètre adapté (`axis=0`).
Calculez et affichez la **moyenne générale de chaque élève** en modifiant la direction du calcul avec l'axe horizontal (`axis=1`).
Supprimez la colonne `'Reseaux'` du DataFrame en utilisant la méthode `.drop()` avec l'argument `axis=1` (ou `columns=...`), puis affichez le DataFrame résultant.
