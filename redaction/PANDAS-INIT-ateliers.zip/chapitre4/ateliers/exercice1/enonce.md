> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 4 : Présentation un DataFrame | Exercice 1*

---

# Chapitre 4 : Présentation un DataFrame

**Exercice 1 :** Création d'un DataFrame à partir d'un dictionnaire et manipulation des propriétés structurelles

Vous gérez le parc informatique d'une PME. On dispose des informations relatives à trois ordinateurs portables en stock, qu'on doit structurer sous la forme d'un `DataFrame` Pandas pour en analyser les caractéristiques.

À l'aide d'un dictionnaire de listes, créez un `DataFrame` nommé `df_parc` contenant les données suivantes :
* **`Modele`** : `['Latitude 5420', 'ThinkPad T14', 'MacBook Pro']`
* **`Marque`** : `['Dell', 'Lenovo', 'Apple']`
* **`Prix_HT`** : `[950.0, 1100.0, 1850.0]`
* **`En_Stock`** : `[True, False, True]`

Attribuez un index explicite personnalisé au DataFrame en utilisant la liste d'identifiants : `['PC_01', 'PC_02', 'PC_03']`.
Affichez les dimensions du DataFrame via l'attribut `.shape` ainsi que les types de données de chaque colonne via `.dtypes`.
Extrayez la colonne `Prix_HT` dans une variable, puis vérifiez et affichez son type exact à l'aide de la fonction `type()` pour confirmer qu'il s'agit bien d'une `Series`.
