> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 5 : Manipuler un DataFrame | Exercice 1*

---

# Chapitre 5 : Manipuler un DataFrame

**Exercice 1 :** Importez un petit fichier CSV et affichez les noms des colonnes à l'aide de l'attribut approprié.
