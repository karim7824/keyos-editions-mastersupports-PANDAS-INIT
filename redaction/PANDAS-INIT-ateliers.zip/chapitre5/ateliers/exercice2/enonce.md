> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 5 : Manipuler un DataFrame | Exercice 2*

---

# Chapitre 5 : Manipuler un DataFrame

**Exercice 2 :** Créez un DataFrame à partir d'un dictionnaire, puis utilisez `.iloc` pour extraire uniquement la première colonne de toutes les lignes.
