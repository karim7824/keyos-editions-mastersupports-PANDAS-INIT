> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 16 : Étude de cas | Exercice 1*

---

# Chapitre 16 : Étude de cas

**Exercice 1 :** Analyse par discipline sportive

À l'aide du DataFrame nettoyé `df_propre` :

Réalisez un groupement (`groupby`) sur la colonne `Discipline` pour compter le nombre total d'épreuves disputées.
Identifiez la discipline qui a mobilisé le plus grand nombre d'athlètes uniques.
