> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 16 : Étude de cas | Exercice 2*

---

# Chapitre 16 : Étude de cas

**Exercice 2 :** Suivi temporel des performances

Convertissez la colonne `Date_Epreuve` en index temporel (`DatetimeIndex`).
Utilisez un regroupement par date (`resample` ou `groupby` sur la date) pour tracer l'évolution quotidienne du nombre total de médailles décernées au cours de la quinzaine olympique.
