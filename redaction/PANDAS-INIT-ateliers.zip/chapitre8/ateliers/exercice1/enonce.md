> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 8 : Nettoyage et Préparation des Données | Exercice 1*

---

# Chapitre 8 : Nettoyage et Préparation des Données

**Exercice 1 :** Détection et correction des anomalies de texte et de valeurs manquantes

On dispose du DataFrame suivant simulant des inscrits à une newsletter :

```python
import pandas as pd
import numpy as np

df_inscrits = pd.DataFrame({
    'Nom': [' Alice ', 'BOB', 'charlie', ' Alice ', np.nan],
    'Age': [25, np.nan, 30, 25, 45],
    'Score': [85, 90, np.nan, 85, 120] # 120 est une valeur aberrante (score max = 100)
})

```

Supprimez les lignes strictement dupliquées.
Nettoyez la colonne `Nom` pour supprimer les espaces superflus et homogénéiser la casse (première lettre en majuscule).
Remplacez les âges manquants par la médiane des âges, et corrigez le score aberrant (> 100) en y insérant une valeur manquante (`np.nan`) avant de combler les scores par la moyenne.
