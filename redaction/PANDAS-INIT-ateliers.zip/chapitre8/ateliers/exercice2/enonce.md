> ⚠️ **AVIS DE CONFIDENTIALITÉ & PROPRIÉTÉ INTELLECTUELLE**
> > **© 2026 Keyos-Éditions. Tous droits réservés.**
> > *Document strictement confidentiel - Support de formation*
> > *Chapitre : # Chapitre 8 : Nettoyage et Préparation des Données | Exercice 2*

---

# Chapitre 8 : Nettoyage et Préparation des Données

**Exercice 2 :** Optimisation mémoire et traitement de chaînes

Créez un DataFrame contenant 10 000 lignes avec deux colonnes :

* `Departement` : contenant aléatoirement les valeurs `'75'`, `'69'`, `'13'` et `'31'`.
* `Montant` : des chaînes de caractères représentant des prix textuels (ex : `"150.50 €"`).

Nettoyez la colonne `Montant` pour la convertir en un type numérique (`float64`).
Convertissez la colonne `Departement` en type `category`.
Vérifiez l'empreinte mémoire du DataFrame optimisé à l'aide de `.info()`.
